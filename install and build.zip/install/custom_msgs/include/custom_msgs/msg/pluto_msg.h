// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_msgs:msg/PlutoMsg.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_MSGS__MSG__PLUTO_MSG_H_
#define CUSTOM_MSGS__MSG__PLUTO_MSG_H_

#include "custom_msgs/msg/detail/pluto_msg__struct.h"
#include "custom_msgs/msg/detail/pluto_msg__functions.h"
#include "custom_msgs/msg/detail/pluto_msg__type_support.h"

#endif  // CUSTOM_MSGS__MSG__PLUTO_MSG_H_
