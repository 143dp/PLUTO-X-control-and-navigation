// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_msgs:msg/PlutoMsgAP.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_MSGS__MSG__PLUTO_MSG_AP_H_
#define CUSTOM_MSGS__MSG__PLUTO_MSG_AP_H_

#include "custom_msgs/msg/detail/pluto_msg_ap__struct.h"
#include "custom_msgs/msg/detail/pluto_msg_ap__functions.h"
#include "custom_msgs/msg/detail/pluto_msg_ap__type_support.h"

#endif  // CUSTOM_MSGS__MSG__PLUTO_MSG_AP_H_
