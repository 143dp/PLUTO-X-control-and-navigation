// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_msgs:srv/PlutoPilot.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_MSGS__SRV__PLUTO_PILOT_H_
#define CUSTOM_MSGS__SRV__PLUTO_PILOT_H_

#include "custom_msgs/srv/detail/pluto_pilot__struct.h"
#include "custom_msgs/srv/detail/pluto_pilot__functions.h"
#include "custom_msgs/srv/detail/pluto_pilot__type_support.h"

#endif  // CUSTOM_MSGS__SRV__PLUTO_PILOT_H_
